/** Automatically generated file. DO NOT MODIFY */
package io.vov.vitamio.demo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}